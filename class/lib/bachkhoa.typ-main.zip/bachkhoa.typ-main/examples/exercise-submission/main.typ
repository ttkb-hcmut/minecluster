#let doc(content) = {
	set text(size: 11pt, font: "New Computer Modern")
	content
}

#let frontcover__canvas(content) = {
	place(top + center, scope: "parent", float: true, [#content #v(16pt)])
}

#let frontcover__bklogo = {
	image(
		"hcmut-withring.svg"
	)
}

#let frontcover__title(content) = {
	show heading: it => {
		set text(weight: "thin")
		it
	}
	content
}

#let frontcover__key_value(key, value) = {
	[#text(size: 16pt, weight: "semibold", key): #text(size: 16pt, weight: "thin", value)]
}

#let frontcover = (
	canvas: frontcover__canvas,
	bklogo: frontcover__bklogo,
	title : frontcover__title,
	key_value: frontcover__key_value,
)

////////////////////////////

#show: doc

#(frontcover.canvas)[
	#frontcover.bklogo

	#(frontcover.title)[= Natural Language Processing (CO3086)]
	#v(-8pt)
	#(frontcover.title)[= NLP 251 - Lab 6: Linear - Logistic Regression]
	#v(8pt)
	#(frontcover.key_value)([Student], [Le Nguyen Gia Bao (2210216)])
]

= Problem 1

a)

b) Choose (b) model 2. Model b can capture model a. Model a doesn't necessarily capture model b.

c) Choose (a) model 1. Test data is different from train data because we encounter outlier values. Model a is linear where space is split into parts more equally. Speaking of probablisitics, model a should score better through the loss function 

In real life, TODO(kinten)

= Problem 2

= Problem 3

= Problem 4

= Problem 5

= Problem 6

= Problem 7
